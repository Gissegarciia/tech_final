import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { getUserStorage } from '../helpers/getUserStorage';
import { ExceptionOutlined } from "@ant-design/icons";
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';
import { savePdf } from '../helpers/pdf';

const Recibos = () => {

    const [user] = useState(getUserStorage());
    const [recibos, setRecibos] = useState([]);

    useEffect(() => {
        Axios.post("http://localhost:8080/obtener-recibos", {
            idAlumno: user
        }).then((response) => {
            console.log('DATA RECIBOS', response.data);
            setRecibos(response.data);
        }).catch((err) => {
            console.log(err);
        });
    }, [setRecibos, user]);

    const descargarRecibo = (ev, idPago) => {
        ev.preventDefault();
        console.log('ENTRE XD', idPago);
        generar_recibo(idPago);
    }

    const generar_recibo = (idPago) => {
        recibos.map(function (item) {
            if (item.id_pago === idPago) {
                savePdf(
                    <Document>
                        <Page size="A4" style={styles.page}>
                            <View style={styles.section}>
                                <Text># Pago: {item.id_pago}</Text>
                                <Text>Nombre curso: {item.nombre_curso}</Text>
                                <Text>Valor: $COP {item.valor}</Text>
                                <Text>Método de pago: {item.nombre_empresa}</Text>
                                <Text>Correo: {item.correo}</Text>
                                <Text>Nombre: {item.nombre + " " + item.apellido}</Text>
                                <Text>Teléfono: {item.telefono}</Text>
                            </View>
                        </Page>
                    </Document>
                    , `Recibo-${item.id_pago}-${item.nombre_curso}`);
            }
            return '';
        });
    }

    const styles = StyleSheet.create({
        page: {
            flexDirection: 'row',
            backgroundColor: '#E4E4E4'
        },
        section: {
            margin: 10,
            padding: 10,
            flexGrow: 1
        }
    });

    return (
        <>
            {
                (recibos.length > 0) ? (
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col"># Pago</th>
                                <th scope="col">Curso</th>
                                <th scope="col">Valor</th>
                                <th scope="col">Metodo Pago</th>
                                <th scope="col">Nombre Estudiante</th>
                                <th scope="col">Correo</th>
                                <th scope="col">Comprobante</th>
                            </tr>
                        </thead>
                        {
                            recibos.map(item => (
                                <tbody key={item.id_pago}>
                                    <tr>
                                        <th scope="row">{item.id_pago}</th>
                                        <td>{item.nombre_curso}</td>
                                        <td>{item.valor}</td>
                                        <td>{item.nombre_empresa}</td>
                                        <td>{item.nombre + " " + item.apellido}</td>
                                        <td>{item.correo}</td>
                                        <td><button className="btn btn-dark btn-sm" onClick={(ev) => descargarRecibo(ev, item.id_pago)}>Descargar</button></td>
                                    </tr>
                                </tbody>
                            ))
                        }
                    </table>
                ) : (
                    <>
                        <div className="alert alert-dark" role="alert">
                            <ExceptionOutlined /> ¡No has comprado ningún curso en la plataforma!
                        </div>
                    </>
                )
            }
        </>
    )
}

export default Recibos
